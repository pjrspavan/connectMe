export const primaryColor = '#7F99F4';
export const secondaryColor = '#93ABFF';
export const darkTheme = "#282b30"
export const lightTheme = "#ffffff"